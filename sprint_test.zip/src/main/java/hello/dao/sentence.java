package hello.dao;

public class sentence {
}
