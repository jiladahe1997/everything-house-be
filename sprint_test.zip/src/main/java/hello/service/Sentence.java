package hello.service;

public class Sentence {

}
