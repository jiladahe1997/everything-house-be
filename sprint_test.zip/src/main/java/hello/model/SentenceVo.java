package hello.model;

public class SentenceVo {
    int id;
    String author;
    String text;
}
